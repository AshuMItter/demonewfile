﻿using System;


Demo obj = new Demo();
obj.DemoFunc();
Console.WriteLine(obj.MyProperty);


public class Demo
{
    public int MyProperty { get; set; } = 56;
    public void DemoFunc()
    {
        Console.WriteLine("hello World");
    }
}
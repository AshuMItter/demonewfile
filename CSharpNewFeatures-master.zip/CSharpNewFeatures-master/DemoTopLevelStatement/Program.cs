﻿using System;

namespace DemoTopLevelStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I am not to level Statement");
        }
    }
}

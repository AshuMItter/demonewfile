﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoTopLevelStatementReal
{
  public class Class1
    {
        public void Demo()
        {
            Console.WriteLine("I am called by the Top Level Statment");
        }
    }
}

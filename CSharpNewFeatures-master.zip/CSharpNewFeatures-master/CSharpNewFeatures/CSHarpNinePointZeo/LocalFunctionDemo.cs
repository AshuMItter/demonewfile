﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSHarpNinePointZeo
{
    class LocalFunctionDemo
    {
        public static void NormalFunction()
        {
            Console.WriteLine("Hello From Normal Function");

            void LocalFunction()
            {
                Console.WriteLine("This is local Function");
            }

            LocalFunction();
        }
    }
}

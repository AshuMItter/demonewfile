﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSHarpNinePointZeo
{
    class RecordDemo
    {
        public void DemoClassUpdate()
        {
            var member = new Member
            {
                ID = 1,
                FirstName = "Kirtesh",
                MiddleName = "D",
                LastName = "Shah",
                Address = "Vadodara"
            };

            // updating
            var newMember = new Member
            {
                ID = member.ID,
                FirstName = member.FirstName,
                MiddleName = member.MiddleName,
                LastName = member.LastName,
                Address = "Mumbai"
            };
        }
        public void RecordUpdate()
        {
            var member = new RecordMember
            {
                ID = 1,
                FirstName = "Kirtesh",
                LastName = "Shah",
                Address = "Vadodara"
            };

            var newMember = new RecordMember
            {
                ID = member.ID,
                FirstName = member.FirstName,
                LastName = member.LastName,
                Address = "Mumbai"
            };
            var memberNew = new RecordMember
            {
                ID = 1,
                FirstName = "Kirtesh",
                LastName = "Shah",
                Address = "Vadodara"
            };

            Console.WriteLine($" Value before Update : {memberNew.Address}");
            var MemberUpdated = memberNew with { Address = "Mumbai" };

            Console.WriteLine($" Value after update : {MemberUpdated.Address}");
        }
    }
    public class Member
    {
        public int ID { get; init; }
        public string FirstName { get; init; }
        public string MiddleName { get; init; }
        public string LastName { get; init; }
        public string Address { get; init; }
    }
    public record RecordMember
    {
        public int ID { get; init; }
        public string FirstName { get; init; }
        public string LastName { get; init; }
        public string Address { get; init; }
    }
}

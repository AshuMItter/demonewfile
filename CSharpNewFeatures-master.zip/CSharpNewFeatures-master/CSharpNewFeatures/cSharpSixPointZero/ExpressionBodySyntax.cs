﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.cSharpSixPointZero
{
    class ExpressionBodySyntax
    {
        string fname = "abc", lname = "pqr";
        public void Demo()
        {
            DisplayNameOneMoreTimeEDB();
        }
        public override string ToString() => $"{fname} {lname}".Trim();
        public void DisplayName() => Console.WriteLine(ToString());
        
        public void DisplayNameOneMoreTime()
        {
            Console.WriteLine("something..");
        }

        public void DisplayNameOneMoreTimeEDB() => Console.WriteLine("Single Expression"); 

    }

    // read only properties
    public class Location
    {
        private string locationName;

        public Location(string name)
        {
            locationName = name;
        }

        public string Name => locationName;

        public static int MyProperty => 34;

    }
    
}

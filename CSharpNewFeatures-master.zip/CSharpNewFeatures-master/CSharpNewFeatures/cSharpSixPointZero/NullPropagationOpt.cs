﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.cSharpSixPointZero
{
    public class Person
    {
        public int Age { get; set; }
        public string Name { get; set; }
    }
    class NullPropagationOpt
    {
        Person person = new Person();
        
        public  void NullPropagationOptrs()
        {

           // person.Name = "Joe";


            
            Console.WriteLine(person.Name ?? "Not Null");

            
        
        }

        public void TraditionalNull()
        {
            if(person.Name != null)
            {
                Console.WriteLine("not null");
            }
            else
            {
                Console.WriteLine("null");
            }
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.cSharpSixPointZero
{
    class AutoPropertyIniTializers
    {

        // propery with backing field
        int age = 45;
        public int Age { get { return age; } set { age = value; } }

        // auto implemented properties
        public decimal Tax { get; set; }


        

        //auto properties initializers
        public string MyProperty { get; set; } = "Akash";

        public decimal Income { get; set; } = 45.78m;

        public int DemoInt { get; set; } = 56;

        public int MyPropertyOne
        {
            get { return 34; }
            set
            {

                Console.WriteLine(nameof(value));
            }
        }


    }
}

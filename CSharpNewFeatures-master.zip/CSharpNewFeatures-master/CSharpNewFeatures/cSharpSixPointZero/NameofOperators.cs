﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.cSharpSixPointZero
{
    class NameofOperators
    {
        private string name;
        public string Name
        {
            get => name;
            set => name = value ?? throw new ArgumentNullException(nameof(value), $"{nameof(Name)} cannot be null");
        }
    }
}

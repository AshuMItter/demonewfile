﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.cSharpSixPointZero
{
    class NewFeatures
    {
        public int MyProperty { get; set; } = 45;

        public int UpgradedmyProperty => 90;

        public void UpgradedMethod() => Console.WriteLine(UpgradedmyProperty);

        Person p = new Person();
        public void Demo() => Console.WriteLine(p.Name ?? "No Name");

        public void MakeACall() => Demo();
    }
    class OldFeatures
    {
        int _back = 45;
        public int MyProperty { 
            get { return _back; } 
            set { _back = value; } 
        
        }
        Person p = new Person();
        public int AnotherMyProperty { get; }


        public void DownGradedMethod()
        {
            Console.WriteLine(AnotherMyProperty);
        }
        public void Demo()
        {
            if(p.Name == null)
            {
                Console.WriteLine("No Name");
            }
        }

        public void CallAMethod()
        {
            Demo();
        }
    }
}

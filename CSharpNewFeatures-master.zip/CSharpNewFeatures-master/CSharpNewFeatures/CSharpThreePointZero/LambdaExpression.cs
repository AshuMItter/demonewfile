﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpThreePointZero
{
    class LambdaExpression
    {
        public delegate void del(int a, int b, int c);
        public void ConvertingToDelegate()
        {
            Func<int, int> square = x => {
                return x * x; 
                
                };
            square(23);

            del one = delegate (int a, int b, int c)
            {
                Console.WriteLine("Hello world");
            };
            // lambda expression

            del val = (a,c,b) => { Console.WriteLine(a); } ;


        }
    }
}

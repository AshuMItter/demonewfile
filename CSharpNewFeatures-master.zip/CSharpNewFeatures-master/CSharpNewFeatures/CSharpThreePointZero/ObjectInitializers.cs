﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpThreePointZero
{
    class ObjectInitializers
    {
        public void DemoObjectInitalizerClass()
        {
            // earlier
            Cat catMando = new Cat();
            catMando.Age = 34;
            catMando.Name = "Catmando";

            // object initilizers
            Cat cat = new Cat { Age = 10, Name = "Fluffy" };
            Cat sameCat = new Cat("Fluffy") { Age = 10 };
        }
        public void DemoObjectInitializetList()
        {
            List<int> digits = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            // List<int> digits2 = new List<int> { 0 + 1, 12 % 3, MakeInt() };

            // object initializers
            List<Cat> cats = new List<Cat>
            {
              new Cat{ Name = "Sylvester", Age=8 },
                new Cat{ Name = "Whiskers", Age=2 },
                new Cat{ Name = "Sasha", Age=14 }
            };

            // object initializers
            var dictionary = new Dictionary<int, string>()
            {
                {23,"Leo" },
                {34,"Neo" }
            };



        }
    }
    public class Cat
    {
        // Auto-implemented properties.
        public int Age { get; set; }
        public string Name { get; set; }

        public Cat()
        {
        }

        public Cat(string name)
        {
            this.Name = name;
        }
    }
}

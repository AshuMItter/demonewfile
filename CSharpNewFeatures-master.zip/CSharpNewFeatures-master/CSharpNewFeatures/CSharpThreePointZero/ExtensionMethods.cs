﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpThreePointZero
{
    class ExtensionMethods
    {
    }
    
        public static class MyExtensions
        {

            public static int WordCount(this string str)
            {
                return str.Split(new char[] { ' ', '.', '?' },
                                 StringSplitOptions.RemoveEmptyEntries).Length;
            }

        public static int Multiply(this DemoAdd obj, int num1, int num2)
        {
            return num1 * num2;
        }

    }

    }


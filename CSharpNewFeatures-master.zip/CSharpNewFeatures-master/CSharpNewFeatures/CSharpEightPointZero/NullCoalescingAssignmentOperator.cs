﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSharpEightPointZero
{
    class NullCoalescingAssignmentOperator
    {
        public static void Demo()
        {
            List<string> names = new List<string>();
            
            string i = null;

            names.Add(i ??= "Not Found");

            string val = i ??= "Leo";

            foreach (var item in names)
            {
                Console.WriteLine(item);
            }
        }
    }
}

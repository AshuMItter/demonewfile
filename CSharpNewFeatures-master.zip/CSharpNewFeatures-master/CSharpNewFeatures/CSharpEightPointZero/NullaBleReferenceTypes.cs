﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpNewFeatures.CSharpEightPointZero
{
    class NullaBleReferenceTypes
    {
        public void Demo()
        {
            #nullable enable
            string? val;

           

        }
    }
}

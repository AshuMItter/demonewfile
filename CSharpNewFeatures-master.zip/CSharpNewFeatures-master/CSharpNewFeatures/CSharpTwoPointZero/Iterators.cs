﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace CSharpNewFeatures.CSharpTwoPointZero
{
    //used to step through collections such as lists and arrays.
    //iterator method or get accessor performs a custom iteration over a collection
    //An Iterator is an object that can be used to loop through collections, like ArrayList and HashSet. 
    class Iterators
    {
        public static void Demo()
        {
           
            foreach (var item in SomeNumbers())
            {
                Console.WriteLine(item);
            }
        }
        public static System.Collections.IEnumerable SomeNumbers()
        {
            yield return "Ashu";  // current location is saved..
            yield return 4;
            yield return 5;
        }

    }
   public class LoopingDays : IEnumerable
    {
        private string[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

        public IEnumerator GetEnumerator()
        {
            yield return 34;
            yield return 35;
            yield return 36;


        }
    }

}
